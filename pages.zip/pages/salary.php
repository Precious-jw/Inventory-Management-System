<?php
include("config/db_conn.php");

if ($_SESSION['role'] == 0){
    redirect("http://localhost/ims/");
}
?>
<!-- Begin Page Content -->
<div class="container-fluid">

    <!-- Page Heading -->
    <div class="d-sm-flex align-items-center justify-content-between mb-4">
        <h1 class="h3 mb-0 text-gray-900">Pay Salary</h1>
    </div>

    <div class="card shadow mb-4"> <!--begin::Container-->
        <div class="card-header">
            <div class="row">
                <div class="col">
                    <h6 class="m-0 mt-2">Search for Paid Salary</h6>
                </div>
            </div>
        </div>
        <div class="card mb-4 col-12">

            <form id="SearchSalaryForm" method="post"> <!--begin::Body-->
                <div class="card-body row">
                    <div class="mb-3 form-group col-md-3"> 
                        <label><b>Date From</b></label> 
                        <input type="Date" id="dateFrom" name="dateFrom" value="<?= isset($_POST['dateFrom']) ? $_REQUEST['dateFrom'] : '' ?>" class="form-control">
                    </div>
                    <div class="mb-3 form-group col-md-3"> 
                        <label><b>Date To</b></label> 
                        <input type="Date" id="dateTo" name="dateTo" value="<?= isset($_POST['dateTo']) ? $_REQUEST['dateTo'] : '' ?>" class="form-control">
                    </div>
                    <div class="mb-3 form-group col-md-3"> 
                        <label><b>Name of Staff</b></label> 
                        <input type="text" id="staff_name" name="staff_name" value="<?= isset($_POST['staff_name']) ? $_REQUEST['staff_name'] : '' ?>" class="form-control">
                    </div>
                    <div class="mb-3 form-group col-md-3"> 
                        <label><b>Amount</b></label> 
                        <input type="number" id="amount" name="amount" value="<?= isset($_POST['amount']) ? $_REQUEST['amount'] : '' ?>" class="form-control">
                    </div>
                    <div class="mb-3 form-group col-md-3"> 
                        <label><b>Remarks</b></label> 
                        <input type="text" id="remarks" name="remarks" value="<?= isset($_POST['remarks']) ? $_REQUEST['remarks'] : '' ?>" class="form-control">
                    </div>
                    <div class="mt-2 form-group col-md-6"> 
                        <label><b></b></label> <br>
                        <button type="submit" class="btn btn-primary" name="search">Search</button> 
                        <a href="<?= base_url."salary" ?>" class="btn btn-success">Reset</a> 
                    </div>
                </div> <!--end::Body--> <!--begin::Footer-->
            </form> <!--end::Form-->
        </div>
    </div> <!--end::App Content-->

    <div class="card shadow">
        <div class="card-header">
            <div class="row">
                <div class="col">
                    <h6 class="m-0 mt-2">All Paid Salaries</h6>
                </div>
                <div class="col-auto">
                    <button class="btn btn-primary btn-sm add-btn" data-bs-toggle="modal" data-bs-target="#add_salary_modal">Add New</button>
                </div>
            </div>
        </div>
        <div class="card-body">
            <!-- Loader -->
            <div id="loader-container">
                <div class="loader"></div>
            </div>
            <div class="table-responsive">
                <table class="table table-bordered text-gray-900" id="dataTable">
                    <thead>
                        <tr>
                            <th>S/N</th>
                            <th>Entered by</th>
                            <th>Name of Staff</th>
                            <th>Amount</th>
                            <th>For the month of</th>
                            <th>Date Paid</th>
                            <th>Remarks</th>
                            <th>Action</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                            if (isset($_POST['search'])) {
                                $conditions = [];
                                $params = [];
                                $types = "";

                                if (!empty($_POST['dateFrom'])) {
                                    $conditions[] = "date >= ?";
                                    $params[] = $_POST['dateFrom'];
                                    $types .= "s";
                                }

                                if (!empty($_POST['dateTo'])) {
                                    $conditions[] = "date < ? + INTERVAL 1 DAY";
                                    $params[] = $_POST['dateTo'];
                                    $types .= "s";
                                }

                                if (!empty($_POST['staff_name'])) {
                                    $conditions[] = "staff_name LIKE ?";
                                    $params[] = "%" . $_POST['staff_name']. "%";
                                    $types .= "s";
                                }

                                if (!empty($_POST['amount'])) {
                                    $conditions[] = "amount LIKE ?";
                                    $params[] = "%" . $_POST['amount']. "%";
                                    $types .= "i";
                                }

                                if (!empty($_POST['remarks'])) {
                                    $conditions[] = "remarks LIKE ?";
                                    $params[] = "%" . $_POST['remarks']. "%";
                                    $types .= "s";
                                }

                                $sql = "SELECT *, salary.id as salary_id FROM salary";
                                if (!empty($conditions)) {
                                    $sql .= " WHERE " . implode(" AND ", $conditions);
                                }

                                $stmt = $conn->prepare($sql);
                                if (!empty($params)) {
                                    $stmt->bind_param($types, ...$params);
                                }
                                $stmt->execute();
                                $result = $stmt->get_result();
                            } else {
                                $stmt = $conn->prepare("SELECT *, salary.id as salary_id FROM salary");
                                $stmt->execute();
                                $result = $stmt->get_result();
                            }
                        ?>

                        <?php if ($result->num_rows > 0): ?>
                            <?php $num = 1; ?>
                            <?php foreach ($result as $row): ?>
                                <tr>
                                    <td><?= $num++; ?></td>
                                    <td><?= $row['entered_by']; ?></td>
                                    <td><?= $row['staff_name']; ?></td>
                                    <td>&#8358;<?= number_format($row['amount']); ?></td>
                                    <td><?= $row['month']; ?></td>
                                    <td><?= date('d-M-Y, D H:i A', strtotime($row['date'])); ?></td>
                                    <td><?= $row['remarks']; ?></td>
                                    <td>
                                        <button class="btn btn-primary btn-sm" onclick="updateSalary(<?= $row['salary_id']; ?>)">Update</button>
                                        <button class="btn btn-danger btn-sm" onclick="deleteSalary(<?= $row['salary_id']; ?>)">Delete</button>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php endif; ?>

                        <?php $stmt->close(); ?>

                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Content Row -->

</div>
<!-- /.container-fluid -->

<?php
include('includes/salary_modal.php');
?>


<script>
    /*Show modal
    $(function() {
        $('.add-btn').click(function(e) {
            e.preventDefault();
            $('#add_product_modal').modal('show');
        });
    });*/

    // Get salary to update
    function updateSalary(salary_id) {
        $("#edit_salary_id").val(salary_id);

        $.post("php/salary/get.php", {
            salary_id: salary_id
        }, function(data, status) {
            var id = JSON.parse(data);
            $('#edit_staff_name').val(id.staff_name);
            $('#edit_amount').val(id.amount);
            $('#edit_month').val(id.month);
            $('#edit_remarks').val(id.remarks);
        })
        $("#update_salary_modal").modal("show"); //Show the modal
    }

    // Get product to delete
    function deleteSalary(salary_id) {
        $("#delete_salary_id").val(salary_id);

        $.post("php/salary/delete.php", {
            salary_id: salary_id
        }, function(data, status) {
            var id = JSON.parse(data);
        })
        $("#delete_salary_modal").modal("show"); //Show the modal
    }
</script>