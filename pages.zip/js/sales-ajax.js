$(document).ready(function(){
    //Add Sales
    $("#saleForm").submit(function(event){
        event.preventDefault();
        
        //Get the Data from the input
        var customer_name = $("#customer_name").val();
        var product = $("#product_name").val();
        var quantity = $("#quantity").val();
        var payment = $("#select_payment").val();
        var paid = $("#paid").val();

        //Check if the input fields are empty
        if(product === "" || quantity <= 0 || payment === "" || paid < 0){
            errorMessage("Some fields are required");
            $("#loader-container").hide(); //Hide the loader if there's an error
        } else {
            //Send the date to the PHP Script using AJAX
            $.ajax({
                type: "POST",
                url: "php/sales/add.php",
                data: $(this).serialize() + "&action=addSales",
                success: function (response){
                    try {
                        var jsonResponse = JSON.parse(response);
                    } catch (e) {
                        errorMessage("Unexpected server response.");
                        return;
                    }
                    //Display the message
                    successMessage(
                        jsonResponse.status_code === "error" ? "error" : "success",
                        jsonResponse.status
                    );

                    if(jsonResponse.status_code === "success"){
                        $("#add_sales_modal").modal("hide"); //Hide the modal
                        $("#saleForm")[0].reset(); //Reset the form after submission
                        $("#loader-container").show(); //Show the loader

                        //Reload the current page
                        setTimeout(function(){
                            location.reload();
                        }, 1500);
                    } else if(jsonResponse.status_code === "error") {
                        $("#loader-container").hide(); //Hide the loader if there's an error
                    }
                }, 
                error: function(xhr, status, error){
                    var errorMessage = "An error occurred while adding the sale.";
                    if(xhr.responseText){
                        errorMessage = JSON.parse(xhr.responseText).status;
                    }
                    errorMessage(errorMessage);
                    $("#loader-container").hide(); //Hide the loader if there's an error
                }
            })
        }
    });

    //Update Sales
    $("#UpdateSaleForm").submit(function(event){
        event.preventDefault();
        var updateQuantity = $("#edit_quantity").val();
        var updatePayment = $("#update_select_payment").val();
        var edit_customer_name = $("#edit_customer_name").val();
        var edit_product_name = $("#edit_product_name").val();
        var edit_select_payment = $("#edit_select_payment").val();
        var edit_paid = $("#edit_paid").val();

        if(updatePayment === "" || edit_customer_name === "" || updateQuantity <= 0 || edit_product_name === "" || edit_select_payment === "" || edit_paid < 0){
            errorMessage("Some fields are required");
            $("#loader-container").hide(); //Hide the loader if there's an error
        } else {
            //Send the data to the PHP Script using AJAX
            $.ajax({
                type: "POST",
                url: "php/sales/update.php",
                data: $(this).serialize() + "&action=updateSales",
                success: function (response){
                    try {
                        var jsonResponse = JSON.parse(response);
                    } catch (e) {
                        errorMessage("Unexpected server response.");
                        return;
                    }
    
                    //Display the message
                    successMessage(
                        jsonResponse.status_code === "error" ? "error" : "success",
                        jsonResponse.status
                    );
    
                    if(jsonResponse.status_code === "success"){
                        $("#update_sales_modal").modal("hide"); //Hide the modal
                        $("#loader-container").show(); //Show the loader
    
                        //Reload the current page
                        setTimeout(function(){
                            location.reload();
                        }, 1500);
                    } else if(jsonResponse.status_code === "error") {
                        $("#loader-container").hide(); //Hide the loader if there's an error
                    }
                }, 
                error: function(xhr, status, error){
                    var errorMessage = "An error occurred while updating the sale.";
                    if(xhr.responseText){
                        errorMessage = JSON.parse(xhr.responseText).status;
                    }
                    errorMessage(errorMessage);
                    $("#loader-container").hide(); //Hide the loader if there's an error
                }
            })
        }
        
    });

    //Delete Sales
    $("#deleteSaleForm").submit(function(event){
        event.preventDefault();
        
        //Send the data to the PHP Script using AJAX
        $.ajax({
            type: "POST",
            url: "php/sales/delete.php",
            data: $(this).serialize() + "&action=deleteSale",
            success: function (response){
                try {
                    var jsonResponse = JSON.parse(response);
                } catch (e) {
                    errorMessage("Unexpected server response.");
                    return;
                }

                //Display the message
                successMessage(
                    jsonResponse.status_code === "error" ? "error" : "success",
                    jsonResponse.status
                );

                if(jsonResponse.status_code === "success"){
                    $("#delete_sales_modal").modal("hide"); //Hide the modal
                    $("#loader-container").show(); //Show the loader

                    //Reload the current page
                    setTimeout(function(){
                        location.reload();
                    }, 1500);
                } else if(jsonResponse.status_code === "error") {
                    $("#loader-container").hide(); //Hide the loader if there's an error
                }
            }, 
            error: function(xhr, status, error){
                var errorMessage = "An error occurred while deleting the sale.";
                if(xhr.responseText){
                    errorMessage = JSON.parse(xhr.responseText).status;
                }
                errorMessage(errorMessage);
                $("#loader-container").hide(); //Hide the loader if there's an error
            }
        })
    });
})