<!-- Add Sale Modal -->
<div class="modal fade" id="add_sales_modal" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fs-5 text-gray-900" id="exampleModalLabel">Add new Sales</h5>
      </div>
      <form id="saleForm" action="">
        <div class="modal-body">
          <div class="container-fluid">

            <!-- 🛒 Product Selection Section -->
            <div class="row g-3 mb-4">
              <div class="col-md-3">
                <label for="select_product" class="form-label text-black">Select Product <strong style="color:red">*</strong></label>
                <select id="select_product" class="form-control text-gray-900">
                  <option value="">Search Product</option>
                  <?php
                  $sql = "SELECT *, product.id AS product_id FROM product";
                  $stmt = $conn->prepare($sql);
                  $stmt->execute();
                  $result = $stmt->get_result();
                  if ($result->num_rows > 0) {
                    foreach ($result as $row) {
                      echo '<option value="' . $row['sale_price'] . '">' . $row['product_name'] . '</option>';
                    }
                  }
                  $stmt->close();
                  ?>
                </select>
              </div>

              <div class="col-md-3">
                <label for="product_name" class="form-label text-black">Product Name</label>
                <input type="text" readonly class="form-control text-gray-900" name="product" id="product_name">
              </div>

              <div class="col-md-2">
                <label for="purchase_price" class="form-label text-black">Price (₦)</label>
                <input type="number" readonly class="form-control text-gray-900" name="purchase_price" id="purchase_price">
              </div>

              <div class="col-md-2">
                <label for="quantity" class="form-label text-black">Qty <strong style="color:red">*</strong></label>
                <input type="number" class="form-control text-gray-900" name="quantity" id="quantity">
              </div>

              <div class="col-md-2">
                <label for="total" class="form-label text-black">Total</label>
                <input type="number" readonly class="form-control text-gray-900" name="total" id="total" value="">
              </div>
            </div>

            <!-- 👤 Customer Info Section -->
            <div class="row g-3 mb-4">
              <div class="col-md-4">
                <label for="customer_name" class="form-label text-black">Customer Name <strong style="color:red">*</strong></label>
                <input type="text" class="form-control text-gray-900" name="customer_name" id="customer_name">
              </div>

              <div class="col-md-4">
                <label for="customer_phone" class="form-label text-black">Customer Phone Number</label>
                <input type="number" class="form-control text-gray-900" name="customer_phone" id="customer_phone">
              </div>

              <div class="col-md-4">
                <label for="select_payment" class="form-label text-black">Payment Method <strong style="color:red">*</strong></label>
                <select id="select_payment" name="payment" class="form-control text-gray-900">
                  <option value="">Select Method</option>
                  <option value="Cash">Cash</option>
                  <option value="Transfer">Transfer</option>
                  <option value="POS">POS</option>
                </select>
              </div>
            </div>

            <!-- 💵 Payment Summary -->
            <div class="row g-3 mb-4">
              <div class="col-md-4">
                <label for="discount" class="form-label text-black">Discount Amount (₦)</label>
                <input type="number" class="form-control text-gray-900" name="discount" id="discount" value="">
              </div>

              <div class="col-md-4">
                <label for="paid" class="form-label text-black">Amount Paid (₦) <strong style="color:red">*</strong></label>
                <input type="number" class="form-control text-gray-900" name="paid" id="paid" value="">
              </div>

              <div class="col-md-4">
                <label for="grand_total" class="form-label text-black">Remaining Amount</label>
                <input type="number" readonly class="form-control text-gray-900" name="grand_total" id="grand_total" value="">
              </div>
            </div>

            <div class="row g-3 mb-4">
              <div class="col-md-12">
                <label for="comments" class="form-label text-black">Comments (Optional)</label>
                <textarea class="form-control text-gray-900" name="comments" id="comments"></textarea>
              </div>
            </div>

          </div>
        </div>

        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" name="submit" class="btn btn-primary">Save</button>
        </div>
      </form>
    </div>
  </div>
</div>



<!-- Update Sales Modal -->
<div class="modal fade" id="update_sales_modal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true" data-bs-backdrop="static">
  <div class="modal-dialog modal-xl">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title fs-5 text-gray-900" id="exampleModalLabel">Edit Sale</h5>
      </div>
      <form id="UpdateSaleForm">
        <div class="modal-body">
          <input type="hidden" name="update_sale_id" id="edit_sale_id">

          <!-- 🛒 Product Section -->
          <div class="container-fluid">
            <div class="row g-3 mb-4">
              <div class="col-md-3">
                <label for="edit_select_product" class="form-label text-black">Select Product</label>
                <select name="update_select_product" class="form-control text-gray-900" id="edit_select_product">
                  <option value="">Select Product</option>
                  <?php
                  $sql = "SELECT *, product.id AS product_id FROM product";
                  $stmt = $conn->prepare($sql);
                  $stmt->execute();
                  $result = $stmt->get_result();
                  if ($result->num_rows > 0) {
                    foreach ($result as $row) {
                      echo '<option value="' . $row['sale_price'] . '">' . $row['product_name'] . '</option>';
                    }
                  }
                  $stmt->close();
                  ?>
                </select>
              </div>

              <div class="col-md-3">
                <label for="edit_product_name" class="form-label text-black">Product Name</label>
                <input type="text" readonly class="form-control text-gray-900" name="update_product" id="edit_product_name">
              </div>

              <div class="col-md-3">
                <label for="edit_price" class="form-label text-black">Price</label>
                <input type="number" readonly class="form-control text-gray-900" name="update_price" id="edit_price" value="">
              </div>

              <div class="col-md-3">
                <label for="edit_quantity" class="form-label text-black">Qty <strong style="color:red">*</strong></label>
                <input type="number" class="form-control text-gray-900" name="update_quantity" id="edit_quantity">
              </div>

            </div>

            <!-- 👤 Customer Section -->
            <div class="row g-3 mb-4">
              <div class="col-md-4">
                <label for="edit_customer_name" class="form-label text-black">Customer Name <strong style="color:red">*</strong></label>
                <input type="text" class="form-control text-gray-900" name="update_customer_name" id="edit_customer_name">
              </div>

              <div class="col-md-4">
                <label for="edit_customer_phone" class="form-label text-black">Customer Phone Number</label>
                <input type="number" class="form-control text-gray-900" name="update_customer_phone" id="edit_customer_phone">
              </div>

              <div class="col-md-4">
                <label for="edit_select_payment" class="form-label text-black">Payment Method <strong style="color:red">*</strong></label>
                <select id="edit_select_payment" name="update_payment" class="form-control text-gray-900">
                  <option value="">Select Method</option>
                  <option value="Cash">Cash</option>
                  <option value="Transfer">Transfer</option>
                  <option value="POS">POS</option>
                </select>
              </div>
            </div>

            <div class="row g-3 mb-4">
              <div class="col-md-4">
                <label for="discount" class="form-label text-black">Discount Amount (₦)</label>
                <input type="number" class="form-control text-gray-900" name="update_discount" id="edit_discount" value="">
              </div>

              <div class="col-md-4">
                <label for="edit_paid" class="form-label text-black">Amount Paid (₦) <strong style="color:red">*</strong></label>
                <input type="number" class="form-control text-gray-900" name="update_paid" id="edit_paid" value="">
              </div>

              <div class="col-md-4">
                <label for="edit_total" class="form-label text-black">Amount Remaining</label>
                <input type="number" readonly class="form-control text-gray-900" name="update_total" id="edit_total" placeholder="₦00.00">
              </div>
            </div>

            <div class="row g-3 mb-4">
              <div class="col-md-12">
                <label for="comments" class="form-label text-black">Comments (Optional)</label>
                <textarea type="number" class="form-control text-gray-900" name="update_comments" id="edit_comments"></textarea>
              </div>
            </div>

          </div>
        </div>

        <!-- 💾 Footer -->
        <div class="modal-footer">
          <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
          <button type="submit" name="submit" class="btn btn-primary">Update</button>
        </div>
      </form>
    </div>
  </div>
</div>


<!-- Delete Product Modal -->
<div class="modal" tabindex="-1" id="delete_sales_modal" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h3 class="modal-title text-red">Warning</h3>
                <button type="button" data-bs-dismiss="modal" aria-label="Close"><i class="fas fa-close"></i></button>
            </div>
            <form id="deleteSaleForm">
                <div class="modal-body">
                    <input type="hidden" name="delete_sale_id" id="delete_sale_id">
                    <p><strong>Are you sure you want to delete this Sales Record?</strong></p>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Close</button>
                    <button type="submit" name="submit" class="btn btn-danger">Yes</button>
                </div>
        </div>
    </div>
</div>


<script>
    $(document).ready(function() {
        $('#select_product').selectize({
            sortField: 'text'
        });
        $('#edit_select_product').selectize({
            sortField: 'text'
        });

        function cal_total() {
            var price = $('#purchase_price').val();
            var quantity = $('#quantity').val();
            var total = $('#total').val(price * quantity);
        }
        function edit_total(){
            var editPrice = $('#edit_price').val();     
            var updateDiscount = $('#edit_discount').val();
            var editQuantity = $('#edit_quantity').val();
            var edit_paid = $('#edit_paid').val();
            var editTotal = $('#edit_total').val((editPrice * editQuantity - updateDiscount) - edit_paid);
        }

        function cal_final_total() {
            var total = $('#total').val();            
            var discount = $('#discount').val();
            var paid = $('#paid').val();
            var final_total = $('#grand_total').val(total - discount - paid);
        }

        $('#quantity').keyup(function() {
            cal_total();
            cal_final_total();
        });
        $('#edit_quantity').keyup(function() {
            edit_total();
        });
        $('#discount').keyup(function() {
            cal_final_total();
        });
        $('#edit_discount').keyup(function() {
            edit_total();
        });
        $('#paid').keyup(function() {
            cal_final_total();
        });
        $('#edit_paid').keyup(function() {
            edit_total();
        });
    });

    // add the following onChange script
    $(document).ready(function() {
        $('#select_product').change(function() {
            var price = $(this);
            var purchase_price = $('#purchase_price').val(price.val());
            var name = $("#product_name").val(this.options[this.selectedIndex].text);
            var quantity = $('#quantity').val("");
            var total = $('#total').val("00.00");
            var final_total = $('#grand_total').val("00.00");
        })
        $('#edit_select_product').change(function() {
            var price = $(this);
            var edit_price = $('#edit_price').val(price.val());
            var name = $("#edit_product_name").val(this.options[this.selectedIndex].text);
            var quantity = $('#edit_quantity').val(0);
            var total = $('#edit_total').val("00.00");
            var final_total = $('#grand_total').val("00.00");
        })

    });
</script>