Inventory Management Software is a personal project I embarked on
in order to improve my PHP object oriented programming skills.

It is a web based software that is used to take inventory of products/items in a company and manage sales record.
It also has a user management functionality, allowing the admin to add and remove users
